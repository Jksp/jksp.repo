import re
import urllib2
import sys
import json

def resolve(video_id):
    try:
        f = urllib2.urlopen('https://www.raptu.com/?v=%s' % video_id)

    except urllib2.URLError, e:
        print e
        return False

    html = f.read()
    r = re.search('jwplayer\("home_video"\)\.setup\(.+?"sources": (\[.+?\]).+?\);', html)
    if r:
        video_sources = r.group(1)
        json_data = json.loads(video_sources)
        return {x['label']:x['file'] for x in json_data if 'label'in x}
	
    else:
        return None
		
if __name__ == '__main__':
    movie_data = resolve(sys.argv[1])
    # print movie_data.keys()
    for x in movie_data:
        print movie_data[x],x

