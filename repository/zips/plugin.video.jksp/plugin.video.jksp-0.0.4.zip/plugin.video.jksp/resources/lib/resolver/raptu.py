import re
import urllib2
import sys
import json

def resolve(video_id):
    try:
        req = urllib2.Request("https://www.raptu.com/?v=%s" % video_id, headers={'User-Agent': "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:52.0) Gecko/20100101 Firefox/52.0"})
        html = urllib2.urlopen(req).read()

    except urllib2.URLError, e:
        print e
        return False

    r = re.search('jwplayer\("home_video"\)\.setup\(.+?"sources": (\[.+?\]).+?\);', html)
    if r:
        video_sources = r.group(1)
        json_data = json.loads(video_sources)
        return dict([(x['label'],x['file']) for x in json_data if 'label'in x])
	
    else:
        return None
		
if __name__ == '__main__':
    movie_data = resolve(sys.argv[1])
    if movie_data:
        for x in movie_data:
            print movie_data[x],x

    else:
        print("failed!")
